import socket
import threading
import tkinter as tk
from tkinter import simpledialog, scrolledtext

# Client Configuration
HOST = '127.0.0.1'
PORT = 12345

# TO handle receiving messages from the server
def receive_messages():
    while True:
        try:
            message = client_socket.recv(1024).decode('utf-8')
            if message:
                chat_log.config(state=tk.NORMAL)
                chat_log.insert(tk.END, message + '\n')
                chat_log.config(state=tk.DISABLED)
                chat_log.yview(tk.END)
        except:
            print("An error occurred!")
            client_socket.close()
            break

#TO send messages to the server
def send_message():
    message = message_entry.get()
    if message:
        client_socket.send(message.encode('utf-8'))
        message_entry.delete(0, tk.END)

# GUI Function to start the chat application
def start_chat():
    root = tk.Tk()
    root.title("Chat Application")

    global chat_log
    chat_log = scrolledtext.ScrolledText(root, state=tk.DISABLED)
    chat_log.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

    global message_entry
    message_entry = tk.Entry(root)
    message_entry.pack(padx=10, pady=5, fill=tk.X, expand=True)
    message_entry.bind("<Return>", lambda event: send_message())

    send_button = tk.Button(root, text="Send", command=send_message)
    send_button.pack(padx=10, pady=5)

    threading.Thread(target=receive_messages).start()

    root.mainloop()

#To start client
if __name__ == "__main__":
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((HOST, PORT))

    login = tk.Tk()
    login.withdraw()

    username = simpledialog.askstring("Username", "Please enter your username:", parent=login)

    if username:
        client_socket.send(username.encode('utf-8'))
        start_chat()
