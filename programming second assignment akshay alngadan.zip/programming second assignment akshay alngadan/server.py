import socket
import threading
from database import initialize_database, add_user

# Server Configuration
HOST = '127.0.0.1'
PORT = 12345

# Initialize database
initialize_database()

# List to keep track of connected clients
clients = []


# Function to handle client connections
def handle_client(client_socket, client_address):
    while True:
        try:
            message = client_socket.recv(1024).decode('utf-8')
            if not message:
                break
            broadcast(message, client_socket)
        except:
            clients.remove(client_socket)
            break


# Function to broadcast messages to all clients
def broadcast(message, client_socket):
    for client in clients:
        if client != client_socket:
            try:
                client.send(message.encode('utf-8'))
            except:
                clients.remove(client)


# Main function to start the server
def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((HOST, PORT))
    server_socket.listen(5)
    print(f"Server started on {HOST}:{PORT}")

    while True:
        client_socket, client_address = server_socket.accept()
        username = client_socket.recv(1024).decode('utf-8')
        add_user(username)
        clients.append(client_socket)
        print(f"Connection from {client_address} with username: {username}")
        threading.Thread(target=handle_client, args=(client_socket, client_address)).start()


if __name__ == "__main__":
    start_server()
