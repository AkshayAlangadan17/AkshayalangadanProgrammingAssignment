import socket
import threading
import time
import pytest
from server import start_server
from client import send_message

# Server Configuration
HOST = '127.0.0.1'
PORT = 12345

# Helper function to start the server in a separate thread
def start_test_server():
    server_thread = threading.Thread(target=start_server, daemon=True)
    server_thread.start()
    time.sleep(1)  # Give the server a second to start

@pytest.fixture(scope='module')
def server():
    start_test_server()
    yield

@pytest.fixture(scope='module')
def client1():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((HOST, PORT))
    client_socket.send('User1'.encode('utf-8'))
    yield client_socket
    client_socket.close()

@pytest.fixture(scope='module')
def client2():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((HOST, PORT))
    client_socket.send('User2'.encode('utf-8'))
    yield client_socket
    client_socket.close()

def test_receive_messages(server, client1, client2):
    client2_messages = []

    def handle_messages():
        while True:
            try:
                message = client2.recv(1024).decode('utf-8')
                if message:
                    client2_messages.append(message)
            except:
                break

    threading.Thread(target=handle_messages, daemon=True).start()

    send_message(client1, 'Hello from User1')
    time.sleep(1)  # Give some time for the message to be received

    assert 'Hello from User1' in client2_messages, "User2 should receive the message sent by User1"
