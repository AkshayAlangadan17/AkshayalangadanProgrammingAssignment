import sqlite3
import os
import pytest
from database import initialize_database, add_user

# Use a separate test database to avoid conflicts
TEST_DB = 'test_chat.db'

# Modify database functions to use test database
def initialize_test_database():
    conn = sqlite3.connect(TEST_DB)
    cursor = conn.cursor()
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL
    )
    ''')
    conn.commit()
    conn.close()

def add_test_user(username):
    conn = sqlite3.connect(TEST_DB)
    cursor = conn.cursor()
    cursor.execute('INSERT OR IGNORE INTO users (username) VALUES (?)', (username,))
    conn.commit()
    conn.close()

# Fixture to set up and tear down the test database
@pytest.fixture(scope='module')
def db_connection():
    initialize_test_database()
    conn = sqlite3.connect(TEST_DB)
    yield conn
    conn.close()
    os.remove(TEST_DB)

def test_initialize_database(db_connection):
    cursor = db_connection.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='users';")
    table_exists = cursor.fetchone()
    assert table_exists is not None, "Users table should exist"

def test_add_user(db_connection):
    add_test_user('testuser')
    cursor = db_connection.cursor()
    cursor.execute("SELECT * FROM users WHERE username = 'testuser';")
    user = cursor.fetchone()
    assert user is not None, "User 'testuser' should be added to the database"
